﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using Excepciones;

namespace Archivos
{
    [Serializable]
    public class Xml<T> : IArchivo<T>
    {
        /// <summary>
        ///  guarda los datos indicados en un archivo XML
        /// </summary>
        /// <param name="archivo"> nombre del archivo </param>
        /// <param name="datos"> datos a guardar </param>
        /// <returns> retorna true si se guardaron los datos,
        /// caso contrario, retorna false </returns>
        bool IArchivo<T>.Guardar(string archivo, T datos)
        {
            bool retorno = false;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                TextWriter texto = new StreamWriter(archivo);
                serializer.Serialize(texto, datos);
                texto.Close();
                retorno = true;
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }

            return retorno;
        }

        /// <summary>
        /// lee los datos de un archivo XML
        /// </summary>
        /// <param name="archivo"> nombre del archivo </param>
        /// <param name="datos"> variable donde se van a guardar los datos </param>
        /// <returns> retorna true si se pudo leer el archivo, caso contrario,
        /// retorna false </returns>
        bool IArchivo<T>.Leer(string archivo, out T datos)
        {
            bool retorno = false;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                TextReader texto = new StreamReader(archivo);
                datos = (T)serializer.Deserialize(texto);
                texto.Close();

                retorno = true;
            }
            catch (Exception e)
            {
                datos = default(T);
                throw new ArchivosException(e);
            }

            return retorno;
        }
    }
}
