﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Excepciones;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        /// <summary>
        /// guarda los datos indicados en un archivo de texto
        /// </summary>
        /// <param name="archivo"> nombre del archivo </param>
        /// <param name="datos"> datos a guardar </param>
        /// <returns> retorna true si se guardaron los datos,
        /// caso contrario, retorna false </returns>
        bool IArchivo<string>.Guardar(string archivo, string datos)
        {
            bool retorno = false;

            try
            {
                StreamWriter texto = File.CreateText(archivo);

                texto.WriteLine(datos);

                texto.Close();

                retorno = true;
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }

            return retorno;
        }

        /// <summary>
        /// lee los datos de un archivo de texto
        /// </summary>
        /// <param name="archivo"> nombre del archivo </param>
        /// <param name="datos"> variable donde se van a guardar los datos </param>
        /// <returns> retorna true si se pudo leer el archivo, caso contrario,
        /// retorna false </returns>
        bool IArchivo<string>.Leer(string archivo, out string datos)
        {
            bool retorno = false;
            string linea;

            try
            {
                StreamReader texto = File.OpenText(archivo);
                StringBuilder auxiliar = new StringBuilder();
                
                    linea = texto.ReadToEnd();

                    if (linea != null)
                    {
                        auxiliar.AppendLine(linea);
                    }

                texto.Close();

                datos = auxiliar.ToString();

                retorno = true;
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }

            return retorno;
        }
    }
}
