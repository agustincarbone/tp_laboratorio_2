﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesAbstractas;
using static ClasesInstanciables.Universidad;

namespace ClasesInstanciables
{
    public sealed class Alumno : Universitario
    {
        private EClases claseQueToma;
        private EEstadoCuenta estadoCuenta;

        #region constructores

        public Alumno()
        {

        }

        /// <summary>
        /// inicializa un objeto del tipo alumno
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        /// <param name="claseQueToma"></param>
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, EClases claseQueToma) :
            base(id, nombre, apellido, dni, nacionalidad)
        {            
            this.claseQueToma = claseQueToma;
        }
        
        /// <summary>
        /// inicializa un objeto del tipo alumno
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        /// <param name="claseQueToma"></param>
        /// <param name="estadoCuenta"></param>
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, EClases claseQueToma, EEstadoCuenta estadoCuenta)
        : this(id, nombre, apellido, dni, nacionalidad, claseQueToma)
        {
            this.estadoCuenta = estadoCuenta;
        }

        #endregion

        #region sobrecargas

        /// <summary>
        /// retorna las clases que toma el alumno
        /// </summary>
        /// <returns> retorna las clases en un string </returns>
        protected override string ParticiparEnClase()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendFormat("TOMA CLASE DE {0}", this.claseQueToma);

            return retorno.ToString();
        }

        /// <summary>
        /// verifica si el alumno toma la clase
        /// </summary>
        /// <param name="a"> alumno a verificar </param>
        /// <param name="clase"></param>
        /// <returns> retorna true si toma la clase y no es deudor, 
        /// caso contrario, retorna false </returns>
        public static bool operator ==(Alumno a, EClases clase)
        {
            bool retorno = false;

            if (a.claseQueToma == clase && a.estadoCuenta != EEstadoCuenta.Deudor)
            {
                retorno = true;
            }

            return retorno;
        }

        /// <summary>
        /// verifica si el alumno no toma la clase
        /// </summary>
        /// <param name="a"> alumno a verificar </param>
        /// <param name="clase"></param>
        /// <returns> retorna true si no toma la clase,
        /// caso contrario, retorna false </returns>
        public static bool operator !=(Alumno a, EClases clase)
        {
            bool retorno = false;

            if (a.claseQueToma != clase)
            {
                retorno = true;
            }

            return retorno;
        }

        /// <summary>
        /// retorna los datos de un objeto de tipo alumno
        /// </summary>
        /// <returns> retorna los datos en un string </returns>
        public override string ToString()
        {
            return this.MostrarDatos();
        }

        /// <summary>
        /// retorna los datos de un objeto de tipo alumno
        /// </summary>
        /// <returns> retorna los datos en un string </returns>
        protected override string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendFormat("{0}\nEstado de Cuenta: {1}\n{2}\n", base.MostrarDatos(), this.estadoCuenta, this.ParticiparEnClase());

            return retorno.ToString();
        }

        #endregion

        #region enumerados

        public enum EEstadoCuenta
        {
            AlDia,
            Deudor,
            Becado
        }

        #endregion
    }
}
