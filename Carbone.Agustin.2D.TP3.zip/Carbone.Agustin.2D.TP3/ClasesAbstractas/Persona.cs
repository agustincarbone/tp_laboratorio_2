﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace ClasesAbstractas
{
    public abstract class Persona
    {
        private string nombre;
        private string apellido;
        private ENacionalidad nacionalidad;
        private int dni;

        #region propiedades

        /// <summary>
        /// retorna el nombre o setea el valor indicado, previa validacion
        /// </summary>
        public string Nombre
        {
            get
            {
                return this.nombre;
            }

            set
            {
                this.nombre = value;
            }
        }

        /// <summary>
        /// retorna el apellido o setea el valor indicado, previa validacion
        /// </summary>
        public string Apellido
        {
            get
            {
                return this.apellido;
            }

            set
            {
                this.apellido = value;
            }
        }

        /// <summary>
        /// retorna la nacionalidad o setea el valor indicado
        /// </summary>
        public ENacionalidad Nacionalidad
        {
            get
            {
                return this.nacionalidad;
            }

            set
            {
                this.nacionalidad = value;
            }
        }

        /// <summary>
        /// retorna o setea el numero de DNI en formato int, previa validacion
        /// </summary>
        public int DNI
        {
            get
            {
                return this.dni;
            }

            set
            {
                this.dni = this.ValidarDni(this.Nacionalidad, value);
            }
        }

        /// <summary>
        /// setea el numero de DNI en formato String, previa validacion
        /// </summary>
        public string StringToDNI
        {
            set
            {
                ValidarDni(this.Nacionalidad, value);
            }
        }

        #endregion

        #region constructores

        public Persona()
        { }

        /// <summary>
        /// inicializa un objeto del tipo persona con los valores indicados
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }

        /// <summary>
        /// inicializa un objeto del tipo persona con los valores indicados
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {
            this.DNI = dni;
        }

        /// <summary>
        /// inicializa un objeto del tipo persona con los valores indicados
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad) : this(nombre, apellido, nacionalidad)
        {            
            this.StringToDNI = dni;
        }

        #endregion

        #region sobrecargas

        /// <summary>
        /// retorna los datos de un objeto de tipo Persona
        /// </summary>
        /// <returns> retorna todos los datos en un string </returns>
        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendFormat("Nombre Completo: {0}, {1} \nNacionalidad: {2} \n", this.Apellido, this.Nombre, this.Nacionalidad);
            return retorno.ToString();
        }

        #endregion

        #region validaciones

        /// <summary>
        /// verifica que el DNI corresponda con la nacionalidad
        /// </summary>
        /// <param name="nacionalidad"></param>
        /// <param name="dato"></param>
        /// <returns> retorna el DNI en caso de ser valido, caso contrario, 
        /// lanza una excepcion </returns>
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            int retorno;

            if (nacionalidad == ENacionalidad.Argentino && dato <= 89999999 && dato >= 1)
            {
                retorno = dato;
            }
            else if (nacionalidad == ENacionalidad.Extranjero && dato >= 90000000 && dato <= 99999999)
            {
                retorno = dato;
            }
            else if (dato > 99999999 || dato < 1)
            {
                throw new DniInvalidoException();
            }
            else
            {
                throw new NacionalidadInvalidaException();
            }

            return retorno;
        }

        /// <summary>
        /// verifica que el string solo contenga numeros, y que no tenga mas de 8 caracteres
        /// </summary>
        /// <param name="nacionalidad"></param>
        /// <param name="dato"> string del numero de DNI</param>
        /// <returns> retorna el DNI en caso de ser valido, caso contrario, 
        /// lanza una excepcion </returns>
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int datoAux;
            int retorno;

            if (dato.Count() <= 8)
            {
                if (int.TryParse(dato, out datoAux) == true)
                {
                    // llama a la propiedad DNI para  validar y asignar el valor como int
                    this.DNI = datoAux;
                }
                else
                {
                    throw new DniInvalidoException("el DNI contiene caracteres no validos");
                }

                retorno = this.DNI;
            }
            else
            {
                throw new DniInvalidoException("el DNI contiene mas de 8 caracteres");
            }

            return retorno;
        }

        /// <summary>
        /// verifica que el dato indicado pueda ser un nombre o apellido
        /// </summary>
        /// <param name="dato"> variable que contiene el string a verificar </param>
        /// <returns> retorna el dato en caso de ser valido, caso contrario,
        /// retorna null </returns>
        private string ValidarNombreApellido(string dato)
        {
            string retorno = null;
            int contador = 0;

            foreach (char caracter in dato)
            {
                if (caracter > 'a' && caracter < 'z')
                {
                    contador++;
                }
            }

            if (contador == dato.Count())
            {
                retorno = dato;
            }

            return retorno;
        }

        #endregion

        #region enumerados

        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }

        #endregion
    }
}
