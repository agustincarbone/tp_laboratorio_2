﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstractas
{
    public abstract class Universitario : Persona
    {        
        private int legajo;

        #region constructores

        public Universitario()
        { }

        /// <summary>
        /// inicializa un objeto del tipo universitario con los valores indicados
        /// </summary>
        /// <param name="legajo"> numero de legajo </param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(nombre,apellido,dni,nacionalidad) 
        {
            this.legajo = legajo;
        }

        #endregion

        #region métodos

        /// <summary>
        /// retorna los datos de un objeto de tipo universitario
        /// </summary>
        /// <returns> retorna un string con todos los datos </returns>
        protected virtual string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendFormat("{0} \nLegajo: {1} \n", base.ToString(), this.legajo);

            return retorno.ToString();
        }

        protected abstract string ParticiparEnClase();

        #endregion

        #region sobrecargas

        /// <summary>
        /// compara el tipo dos objetos
        /// </summary>
        /// <param name="obj"> objeto con el que se comparara </param>
        /// <returns> retorna true si son del mismo tipo, caso contrario,
        /// retorna false </returns>
        public override bool Equals(object obj)
        {
            bool retorno = false;

            if (obj.GetType() == this.GetType())
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator ==(Universitario pg1, Universitario pg2)
        {
            bool retorno = false;

            if (pg1.Equals(pg2))
            {
                if (pg1.DNI == pg2.DNI || pg1.legajo == pg2.legajo)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return !(pg1 == pg2);
        }

        #endregion
    }
}
