﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClasesAbstractas;
using ClasesInstanciables;
using Excepciones;


namespace TestExcepcionesPersonas
{
    [TestClass]
    public class TestPersonas
    {
        [TestMethod]
        public void AlumnoRepetido()
        {
            try
            {
                Universidad uni = new Universidad();
                Alumno alumno1 = new Alumno(4, "Juan", "Lopez", "13598689", Persona.ENacionalidad.Argentino, Universidad.EClases.SPD);
                uni += alumno1;
                uni += alumno1;
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(AlumnoRepetidoException));
                return;
            }
        }

        [TestMethod]
        public void SinProfesor()
        {
            try
            {
                Universidad uni = new Universidad();
                Profesor profesor = uni == Universidad.EClases.Laboratorio;
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(SinProfesorException));
                return;
            }
        }

        [TestMethod]
        public void AtributoNull()
        {
            Profesor profesor = new Profesor();

            try
            {
                if (profesor.Apellido != null)
                {
                }
            }
            catch(Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(NullReferenceException));
                return;
            }

        }
    }
}
