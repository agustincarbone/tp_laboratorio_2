﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    /// <summary>
    /// excepcion que se produce cuando la Nacionalidad no corresponde con el DNI
    /// </summary>
    public class NacionalidadInvalidaException : Exception
    {
        private string message = "la nacionalidad no se condice con el numero de DNI";

        /// <summary>
        /// devuelve el mensaje de error
        /// </summary>
        public override string Message
        {
            get
            {
                return this.message;
            }
        }

        public NacionalidadInvalidaException()
        {
        }

        /// <summary>
        /// inicializa un objeto del tipo NacionalidadInvalidaException con un 
        /// mensaje distinto
        /// </summary>
        /// <param name="message"> nuevo mensaje para el objeto </param>
        public NacionalidadInvalidaException(string message)
        {
            this.message = message;
        }
    }
}
