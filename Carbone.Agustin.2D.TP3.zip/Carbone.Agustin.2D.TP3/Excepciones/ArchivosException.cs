﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    /// <summary>
    /// excepcion que se produce cuando el archivo no se pudo guardar o leer
    /// </summary>
    public class ArchivosException : Exception
    {
        private string message;

        /// <summary>
        /// devuelve el mensaje de error
        /// </summary>
        public override string Message
        {
            get
            {
                return this.message;
            }
        }

        /// <summary>
        /// inicializa el mensaje propio con el mensaje de la excepcion recibida
        /// </summary>
        /// <param name="innerException"> excepcion de la que se obtiene el
        /// mensaje </param>
        public ArchivosException(Exception innerException)
        {
            this.message = innerException.Message;
        }
    }
}
