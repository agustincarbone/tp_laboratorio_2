﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    /// <summary>
    /// excepcion que se produce cuando el DNI no es valido
    /// </summary>
    public class DniInvalidoException : Exception
    {
        private string mensajeBase = "el DNI no es valido";

        public DniInvalidoException()
        {
        }

        /// <summary>
        /// inicializa un objeto del tipo DniInvalidoException con un nuevo mensaje
        /// </summary>
        /// <param name="message"> mensaje a asignar </param>
        public DniInvalidoException(string message)
        {
            this.mensajeBase = message;
        }

        /// <summary>
        /// inicializa un objeto del tipo DniInvalidoException con el mensaje
        /// de la excepcion recibida
        /// </summary>
        /// <param name="e"> excepcion de la que se recibe el mensaje </param>
        public DniInvalidoException(Exception e) : this(e.Message)
        {            
        }

        /// <summary>
        /// inicializa un objeto del tipo DniInvalidoException con un nuevo mensaje
        /// y con el mensaje de la excepcion recibida
        /// </summary>
        /// <param name="message"> mensaje a asignar </param>
        /// <param name="e"> excepcion de la que se recibe el mensaje </param>
        public DniInvalidoException(string message, Exception e) : this(message+e.Message)
        {
        }
    }
}
