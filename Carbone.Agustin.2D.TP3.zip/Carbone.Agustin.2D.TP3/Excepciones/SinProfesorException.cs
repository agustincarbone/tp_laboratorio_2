﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    /// <summary>
    /// excepcion que se produce cuando la clase no tiene un profesor asignado
    /// </summary>
    public class SinProfesorException : Exception
    {
        private string message = "no hay profesor para la clase";

        /// <summary>
        /// devuelve el mensaje de error
        /// </summary>
        public override string Message
        {
            get
            {
                return this.message;
            }
        }

        public SinProfesorException()
        {            
        }
    }
}
