﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    /// <summary>
    /// La clase Producto no deberá permitir que se instancien elementos de este tipo.
    /// </summary>
    public abstract class Producto
    {
        public enum Marca
        {
            Serenisima,
            Campagnola,
            Arcor,
            Ilolay,
            Sancor,
            Pepsico
        }

        private Marca marca;
        private string codigoDeBarras;
        private ConsoleColor colorPrimarioEmpaque;

        /// <summary>
        /// es un metodo abstracto sin implementacion
        /// </summary>
        protected abstract short CantidadCalorias { get; }

        /// <summary>
        /// Inicializa un objeto del tipo Producto
        /// </summary>
        /// <param name="patente">Patente del producto</param>
        /// <param name="marca">Marca del producto</param>
        /// <param name="color">Color del envase del producto</param>
        public Producto(string patente, Producto.Marca marca, ConsoleColor color)
        {
            this.codigoDeBarras = patente;
            this.marca = marca;
            this.colorPrimarioEmpaque = color;
        }

        /// <summary>
        /// Publica todos los datos del Producto.
        /// </summary>
        /// <returns>Retorna un string con los datos del producto</returns>
        public virtual string Mostrar()
        {
            return (string) this;
        }

        /// <summary>
        /// Sobrecarga el operador de conversion string para que convierta un objeto del tipo producto
        /// en una cadena de datos del tipo string
        /// </summary>
        /// <param name="producto">Producto a convertir</param>
        public static explicit operator string(Producto producto)
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendFormat("CODIGO DE BARRAS: {0}\r\n", producto.codigoDeBarras);
            cadena.AppendFormat("MARCA          : {0}\r\n", producto.marca.ToString());
            cadena.AppendFormat("COLOR EMPAQUE  : {0}\r\n", producto.colorPrimarioEmpaque.ToString());
            cadena.AppendLine("---------------------");

            return cadena.ToString();
        }

        /// <summary>
        /// Dos productos son iguales si comparten el mismo código de barras
        /// </summary>
        /// <param name="producto1">Primer producto a comparar</param>
        /// <param name="producto2">Segundo producto a comparar</param>
        /// <returns></returns>
        public static bool operator ==(Producto producto1, Producto producto2)
        {
            return (producto1.codigoDeBarras == producto2.codigoDeBarras);
        }
        /// <summary>
        /// Dos productos son distintos si su código de barras es distinto
        /// </summary>
        /// <param name="producto1">Primer producto a comparar</param>
        /// <param name="producto2">Segundo producto a comparar</param>
        /// <returns></returns>
        public static bool operator !=(Producto producto1, Producto producto2)
        {
            return !(producto1.codigoDeBarras == producto2.codigoDeBarras);
        }
    }
}
