﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    public class Snacks : Producto
    {
        /// <summary>
        /// Inicializa un objeto del tipo Snacks
        /// </summary>
        /// <param name="marca">Marca del snack</param>
        /// <param name="patente">Patente del snack</param>
        /// <param name="color">Color del envase del snack</param>
        public Snacks(Marca marca, string patente, ConsoleColor color) : base(patente, marca, color)
        {
        }
        /// <summary>
        /// Los snacks tienen 104 calorías / Retorna la cantidad de calorias que contiene el snack
        /// </summary>
        protected override short CantidadCalorias
        {
            get
            {
                return 104;
            }
        }

        /// <summary>
        /// Muestra TODOS los datos del objeto Snack
        /// </summary>
        /// <returns>Retorna un string con los datos del objeto</returns>
        public override string Mostrar()
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendLine("SNACKS");
            cadena.AppendLine(base.Mostrar());
            cadena.AppendFormat("CALORIAS : {0}", this.CantidadCalorias);
            cadena.AppendLine("");
            cadena.AppendLine("---------------------");

            return cadena.ToString();
        }
    }
}
