﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    public class Dulce : Producto
    {
        /// <summary>
        /// Inicializa un objeto del tipo Dulce con una marca, patente, y color
        /// </summary>
        /// <param name="marca">Marca del dulce</param>
        /// <param name="patente">Patente del dulce</param>
        /// <param name="color">Color del envase del dulce</param>
        public Dulce(Marca marca, string patente, ConsoleColor color) : base(patente, marca, color)
        {
        }

        /// <summary>
        /// Los dulces tienen 80 calorías/ Retorna la cantidad de calorias que contiene el dulce
        /// </summary>
        protected override short CantidadCalorias
        {
            get
            {
                return 80;
            }
        }

        /// <summary>
        /// Muestra TODOS los datos del objeto Dulce
        /// </summary>
        /// <returns>Retorna un strign con los datos del objeto</returns>
        public override sealed string Mostrar()
        {
            StringBuilder cadena = new StringBuilder();

            cadena.AppendLine("DULCE");
            cadena.AppendLine(base.Mostrar());
            cadena.AppendFormat("CALORIAS : {0}", this.CantidadCalorias);
            cadena.AppendLine("");
            cadena.AppendLine("---------------------");

            return cadena.ToString();
        }
    }
}
